<x-guest-layout>
    <x-full-team />
    <x-footer />
</x-guest-layout>